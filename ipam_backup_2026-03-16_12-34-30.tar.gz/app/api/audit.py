# v1.1.26
# Ruter za pregled povijesti aktivnosti (Audit Log) s povećanim limitom i paginacijom.

from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.orm import Session
from app.api.dependencies import get_current_user, get_db
from app.core.models import AuditLog, User
from app.core.ui import templates
import math

router = APIRouter(tags=["audit"])

# KOMENTAR: Dohvaća listu svih revizijskih zapisa s podrškom za paginaciju
@router.get("/")
def list_audit_logs(
    request: Request, 
    db: Session = Depends(get_db), 
    user: User = Depends(get_current_user),
    page: int = Query(1, ge=1),      # Trenutna stranica, zadano je 1
    size: int = Query(50, ge=1, le=100) # POVEĆANO: Sada prikazuje 50 zapisa po stranici umjesto 25
):
    """
    Prikazuje listu zabilježenih događaja s paginacijom radi bržeg učitavanja.
    """
    # KOMENTAR: Izračun koliko zapisa preskočiti (offset) na temelju trenutne stranice
    offset = (page - 1) * size

    # KOMENTAR: Dohvaćanje ukupnog broja zapisa za izračun ukupnog broja stranica
    total_logs = db.query(AuditLog).count()
    total_pages = math.ceil(total_logs / size)

    # KOMENTAR: Dohvaćanje zapisa sortiranih po vremenu (najnoviji prvi) s limitom i pomakom
    logs = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).offset(offset).limit(size).all()
    
    return templates.TemplateResponse("audit_list.html", {
        "request": request,
        "user": user,
        "logs": logs,
        "current_page": page,
        "total_pages": total_pages,
        "total_logs": total_logs, # Dodano da vidiš ukupni broj u HTML-u
        "page_size": size,
        "title": "Audit Logs"
    })