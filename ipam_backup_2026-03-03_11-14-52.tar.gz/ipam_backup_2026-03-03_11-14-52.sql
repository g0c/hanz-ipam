-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: ipam
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(50) NOT NULL,
  `action` varchar(20) NOT NULL,
  `target_type` varchar(20) NOT NULL,
  `target_id` int DEFAULT NULL,
  `details` text,
  `source_ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'2026-03-02 13:05:06','Discovery Engine','DISCOVERY','DEVICE',22,'Pronađen novi aktivni host na mreži: 10.2.2.2',NULL),(2,'2026-03-02 13:05:06','Discovery Engine','DISCOVERY','DEVICE',23,'Pronađen novi aktivni host na mreži: 10.2.2.3',NULL),(3,'2026-03-02 13:05:06','Discovery Engine','DISCOVERY','DEVICE',24,'Pronađen novi aktivni host na mreži: 10.2.2.4',NULL),(4,'2026-03-02 13:05:07','Discovery Engine','DISCOVERY','DEVICE',25,'Pronađen novi aktivni host na mreži: 10.2.2.5',NULL),(5,'2026-03-02 13:05:07','Discovery Engine','DISCOVERY','DEVICE',26,'Pronađen novi aktivni host na mreži: 10.2.2.6',NULL),(6,'2026-03-02 13:05:07','Discovery Engine','DISCOVERY','DEVICE',27,'Pronađen novi aktivni host na mreži: 10.2.2.7',NULL),(7,'2026-03-02 13:05:08','Discovery Engine','DISCOVERY','DEVICE',28,'Pronađen novi aktivni host na mreži: 10.2.2.9',NULL),(8,'2026-03-02 13:05:13','Discovery Engine','DISCOVERY','DEVICE',29,'Pronađen novi aktivni host na mreži: 10.2.2.14',NULL),(9,'2026-03-02 13:05:16','Discovery Engine','DISCOVERY','DEVICE',30,'Pronađen novi aktivni host na mreži: 10.2.2.18',NULL),(10,'2026-03-02 13:05:17','Discovery Engine','DISCOVERY','DEVICE',31,'Pronađen novi aktivni host na mreži: 10.2.2.20',NULL),(11,'2026-03-02 13:05:23','Discovery Engine','DISCOVERY','DEVICE',32,'Pronađen novi aktivni host na mreži: 10.2.2.26',NULL),(12,'2026-03-02 13:05:25','Discovery Engine','DISCOVERY','DEVICE',33,'Pronađen novi aktivni host na mreži: 10.2.2.29',NULL),(13,'2026-03-02 13:05:27','Discovery Engine','DISCOVERY','DEVICE',34,'Pronađen novi aktivni host na mreži: 10.2.2.31',NULL),(14,'2026-03-02 13:05:28','Discovery Engine','DISCOVERY','DEVICE',35,'Pronađen novi aktivni host na mreži: 10.2.2.33',NULL),(15,'2026-03-02 13:05:28','Discovery Engine','DISCOVERY','DEVICE',36,'Pronađen novi aktivni host na mreži: 10.2.2.34',NULL),(16,'2026-03-02 13:05:28','Discovery Engine','DISCOVERY','DEVICE',37,'Pronađen novi aktivni host na mreži: 10.2.2.35',NULL),(17,'2026-03-02 13:05:28','Discovery Engine','DISCOVERY','DEVICE',38,'Pronađen novi aktivni host na mreži: 10.2.2.36',NULL),(18,'2026-03-02 13:05:28','Discovery Engine','DISCOVERY','DEVICE',39,'Pronađen novi aktivni host na mreži: 10.2.2.37',NULL),(19,'2026-03-02 13:05:29','Discovery Engine','DISCOVERY','DEVICE',40,'Pronađen novi aktivni host na mreži: 10.2.2.38',NULL),(20,'2026-03-02 13:05:30','Discovery Engine','DISCOVERY','DEVICE',41,'Pronađen novi aktivni host na mreži: 10.2.2.40',NULL),(21,'2026-03-02 13:05:30','Discovery Engine','DISCOVERY','DEVICE',42,'Pronađen novi aktivni host na mreži: 10.2.2.41',NULL),(22,'2026-03-02 13:05:32','Discovery Engine','DISCOVERY','DEVICE',43,'Pronađen novi aktivni host na mreži: 10.2.2.44',NULL),(23,'2026-03-02 13:05:37','Discovery Engine','DISCOVERY','DEVICE',44,'Pronađen novi aktivni host na mreži: 10.2.2.49',NULL),(24,'2026-03-02 13:05:40','Discovery Engine','DISCOVERY','DEVICE',45,'Pronađen novi aktivni host na mreži: 10.2.2.53',NULL),(25,'2026-03-02 13:05:47','Discovery Engine','DISCOVERY','DEVICE',46,'Pronađen novi aktivni host na mreži: 10.2.2.60',NULL),(26,'2026-03-02 13:05:47','Discovery Engine','DISCOVERY','DEVICE',47,'Pronađen novi aktivni host na mreži: 10.2.2.61',NULL),(27,'2026-03-02 13:05:47','Discovery Engine','DISCOVERY','DEVICE',48,'Pronađen novi aktivni host na mreži: 10.2.2.62',NULL),(28,'2026-03-02 13:05:54','Discovery Engine','DISCOVERY','DEVICE',49,'Pronađen novi aktivni host na mreži: 10.2.2.69',NULL),(29,'2026-03-02 13:06:27','Discovery Engine','DISCOVERY','DEVICE',50,'Pronađen novi aktivni host na mreži: 10.2.2.100',NULL),(30,'2026-03-02 13:06:27','Discovery Engine','DISCOVERY','DEVICE',51,'Pronađen novi aktivni host na mreži: 10.2.2.101',NULL),(31,'2026-03-02 13:06:27','Discovery Engine','DISCOVERY','DEVICE',52,'Pronađen novi aktivni host na mreži: 10.2.2.102',NULL),(32,'2026-03-02 13:06:27','Discovery Engine','DISCOVERY','DEVICE',53,'Pronađen novi aktivni host na mreži: 10.2.2.103',NULL),(33,'2026-03-02 13:06:27','Discovery Engine','DISCOVERY','DEVICE',54,'Pronađen novi aktivni host na mreži: 10.2.2.104',NULL),(34,'2026-03-02 13:07:10','Discovery Engine','DISCOVERY','DEVICE',55,'Pronađen novi aktivni host na mreži: 10.2.2.146',NULL),(35,'2026-03-02 13:07:26','Discovery Engine','DISCOVERY','DEVICE',56,'Pronađen novi aktivni host na mreži: 10.2.2.161',NULL),(36,'2026-03-02 13:09:06','Discovery Engine','DISCOVERY','DEVICE',57,'Pronađen novi aktivni host na mreži: 10.2.2.254',NULL);
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_log`
--

DROP TABLE IF EXISTS `auth_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `success` tinyint(1) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_log`
--

LOCK TABLES `auth_log` WRITE;
/*!40000 ALTER TABLE `auth_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) DEFAULT NULL,
  `ip_addr` varchar(45) NOT NULL,
  `status` enum('active','reserved','offline','unknown') DEFAULT 'unknown',
  `location` varchar(255) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(64) DEFAULT NULL,
  `updated_by` varchar(64) DEFAULT NULL,
  `mac` varchar(32) DEFAULT NULL,
  `vendor` varchar(128) DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `subnet_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_addr` (`ip_addr`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `devices_ibfk_1` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (1,'srv-dc-04','10.2.2.114','active',NULL,'DEV','Server',NULL,'2026-02-27 12:55:54',NULL,'admin',NULL,NULL,'2026-03-03 09:06:03',1),(5,'srv-dc-05','10.2.2.115','active','Zagreb, Radnička 22','PROD','Server','domain kontroler 5','2026-02-27 12:55:54',NULL,'admin',NULL,NULL,'2026-03-03 10:13:50',1),(9,'srv-dc-04333','10.2.2.111','offline',NULL,NULL,NULL,NULL,'2026-02-27 12:55:54',NULL,NULL,NULL,NULL,NULL,1),(10,'aaaaaaaaaaaaaaaa','10.2.2.1','active',NULL,NULL,NULL,NULL,'2026-02-27 12:55:54',NULL,NULL,NULL,NULL,'2026-03-03 09:04:37',1),(16,'4123123123','1.1.1.1','active',NULL,NULL,NULL,NULL,'2026-02-27 12:55:54',NULL,NULL,NULL,NULL,'2026-03-02 07:16:35',NULL),(17,'hostname','1.2.2.2','offline',NULL,NULL,NULL,NULL,'2026-02-27 12:55:54',NULL,NULL,NULL,NULL,NULL,NULL),(18,'4123123123','133.254.21.123','offline',NULL,NULL,NULL,NULL,'2026-02-27 12:55:54',NULL,NULL,NULL,NULL,NULL,NULL),(20,'server1','1.1.1.2','active',NULL,NULL,NULL,NULL,'2026-02-27 12:58:00',NULL,NULL,NULL,NULL,'2026-03-02 07:16:38',NULL),(22,'Unknown-2','10.2.2.2','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:06','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:37',1),(23,'Unknown-3','10.2.2.3','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:06','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:37',1),(24,'Unknown-4','10.2.2.4','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:06','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:37',1),(25,'Unknown-5','10.2.2.5','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:07','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:37',1),(26,'Unknown-6','10.2.2.6','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:07','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:37',1),(27,'Unknown-7','10.2.2.7','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:07','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:37',1),(28,'Unknown-9','10.2.2.9','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:08','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:38',1),(29,'Unknown-14','10.2.2.14','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:13','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:43',1),(30,'Unknown-18','10.2.2.18','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:16','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:46',1),(31,'Unknown-20','10.2.2.20','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:17','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:47',1),(32,'Unknown-26','10.2.2.26','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:23','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:52',1),(33,'Unknown-29','10.2.2.29','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:25','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:55',1),(34,'Unknown-31','10.2.2.31','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:27','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:56',1),(35,'Unknown-33','10.2.2.33','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:28','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:57',1),(36,'Unknown-34','10.2.2.34','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:28','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:57',1),(37,'Unknown-35','10.2.2.35','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:28','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:57',1),(38,'Unknown-36','10.2.2.36','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:28','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:57',1),(39,'Unknown-37','10.2.2.37','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:28','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:57',1),(40,'Unknown-38','10.2.2.38','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:29','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:57',1),(41,'Unknown-40','10.2.2.40','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:30','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:58',1),(42,'Unknown-41','10.2.2.41','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:30','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:04:58',1),(43,'Unknown-44','10.2.2.44','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:32','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:01',1),(44,'Unknown-49','10.2.2.49','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:37','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:05',1),(45,'Unknown-53','10.2.2.53','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:40','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:08',1),(46,'fs','10.2.2.60','active','Zagreb, Radnička 22','PROD','Storage','Synology fs cluster adresa.\r\nAutomatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:47','Discovery Engine','admin',NULL,NULL,'2026-03-03 09:05:15',1),(47,'Unknown-61','10.2.2.61','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:47','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:15',1),(48,'Unknown-62','10.2.2.62','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:47','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:15',1),(49,'Unknown-69','10.2.2.69','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:05:54','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:21',1),(50,'Unknown-100','10.2.2.100','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:06:27','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:53',1),(51,'Unknown-101','10.2.2.101','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:06:27','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:53',1),(52,'Unknown-102','10.2.2.102','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:06:27','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:54',1),(53,'Unknown-103','10.2.2.103','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:06:27','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:54',1),(54,'Unknown-104','10.2.2.104','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:06:27','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:05:54',1),(55,'Unknown-146','10.2.2.146','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:07:10','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:06:36',1),(56,'Unknown-161','10.2.2.161','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:07:26','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:06:51',1),(57,'Unknown-254','10.2.2.254','active',NULL,'DEV','Other','Automatski otkriven putem mrežnog skeniranja (Discovery Engine).','2026-03-02 13:09:06','Discovery Engine',NULL,NULL,NULL,'2026-03-03 09:08:29',1);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Full access'),(2,'operator','Manage devices/subnets, run scans'),(3,'viewer','Read-only access');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `refresh_token` char(64) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refresh_token` (`refresh_token`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnets`
--

DROP TABLE IF EXISTS `subnets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subnets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `vlan_id` int DEFAULT NULL,
  `cidr` varchar(32) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnets`
--

LOCK TABLES `subnets` WRITE;
/*!40000 ALTER TABLE `subnets` DISABLE KEYS */;
INSERT INTO `subnets` VALUES (1,'Serveri i virtualke',60,'10.2.2.0/24','Serverski VLAN - 60','2026-03-02 11:55:49');
/*!40000 ALTER TABLE `subnets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `hashed_password` varchar(255) DEFAULT NULL,
  `full_name` varchar(128) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `mfa_secret` varchar(64) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `role` varchar(20) DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@example.local','$2b$12$aBDaySUxnzoQU6K6/bn/V.EXtFdzAyqKV4SKKYGPJm6gqcRLJMzqm','Administrator',1,NULL,NULL,'2026-02-26 09:36:45','user'),(2,'a.gkonjic',NULL,NULL,'Goran Konjić',1,NULL,NULL,'2026-03-03 11:09:11','user'),(3,'query',NULL,NULL,'query qq. query',1,NULL,NULL,'2026-03-03 11:11:05','user');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-03 11:14:54
