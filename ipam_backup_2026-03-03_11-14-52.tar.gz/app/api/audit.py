# v1.1.25
# Ruter za pregled povijesti aktivnosti (Audit Log) s implementiranom paginacijom.

from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.orm import Session
from app.api.dependencies import get_current_user, get_db
from app.core.models import AuditLog, User
from app.core.ui import templates
import math

router = APIRouter(tags=["audit"])

# --- LISTA REVIZIJSKIH ZAPISA (AUDIT LOGS) ---
@router.get("/")
def list_audit_logs(
    request: Request, 
    db: Session = Depends(get_db), 
    user: User = Depends(get_current_user),
    page: int = Query(1, ge=1),      # Trenutna stranica, zadano je 1
    size: int = Query(25, ge=1, le=100) # Broj zapisa po stranici, zadano 25
):
    """
    Prikazuje listu zabilježenih događaja s paginacijom radi bržeg učitavanja.
    """
    # Izračun koliko zapisa preskočiti
    offset = (page - 1) * size

    # Dohvaćanje ukupnog broja zapisa za izračun stranica
    total_logs = db.query(AuditLog).count()
    total_pages = math.ceil(total_logs / size)

    # Dohvaćanje ograničenog broja logova sortiranih od najnovijih
    logs = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).offset(offset).limit(size).all()
    
    return templates.TemplateResponse("audit_list.html", {
        "request": request,
        "user": user,
        "logs": logs,
        "current_page": page,
        "total_pages": total_pages,
        "page_size": size,
        "title": "Audit Logs"
    })