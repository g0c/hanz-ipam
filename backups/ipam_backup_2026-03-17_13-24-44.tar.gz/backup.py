# v1.0.2
# Skripta za automatski backup baze i koda - IPAM projekt.

import os
import subprocess
from datetime import datetime
from urllib.parse import urlparse
from app.core.config import settings

def run_backup():
    # Postavljanje radnog direktorija i foldera za backup
    base_dir = "/home/su/projects/hanz-ipam"
    backup_dir = os.path.join(base_dir, "backups")
    
    # Kreiramo folder za backup ako već ne postoji
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    # Mijenjamo radni direktorij kako bi tar komanda ispravno radila s relativnim putanjama
    os.chdir(base_dir)

    # 1. Postavljanje varijabli
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_name = f"ipam_backup_{timestamp}"
    sql_file = f"{backup_name}.sql"
    archive_file = os.path.join(backup_dir, f"{backup_name}.tar.gz")
    
    # Sigurno parsiranje DATABASE_URL
    try:
        # Pretvaramo u standardni format kako bi ga urlparse mogao pročitati
        db_uri = settings.DATABASE_URL.replace("mysql+mysqlconnector://", "mysql://")
        parsed = urlparse(db_uri)
        user = parsed.username
        password = parsed.password
        host = parsed.hostname
        db_name = parsed.path.lstrip('/')
    except Exception as e:
        print(f"Greška pri parsiranju DATABASE_URL: {e}")
        return

    print(f"--- Pokrećem backup za projekt: {settings.APP_NAME} ---")

    # 2. Export baze podataka (SQL Dump)
    print(f"[*] Izvozim bazu '{db_name}'...")
    dump_cmd = [
        "mysqldump",
        f"-u{user}",
        f"-h{host}",
        db_name
    ]
    
    # Kopiramo environment i dodajemo lozinku kako bi izbjegli CLI upozorenja i curenje lozinke
    env = os.environ.copy()
    env["MYSQL_PWD"] = password

    with open(sql_file, "w") as f:
        # Prosljeđujemo env u subprocess
        result = subprocess.run(dump_cmd, stdout=f, stderr=subprocess.PIPE, text=True, env=env)
        if result.returncode != 0:
            print(f"[!] Greška kod SQL dump-a: {result.stderr}")
            if os.path.exists(sql_file):
                os.remove(sql_file)
            return

    # 3. Kreiranje komprimirane arhive (Kod + SQL)
    print(f"[*] Pakiram kod i bazu u {archive_file}...")
    
    # Isključujemo nepotrebne foldere, kao i sam folder s backupima da izbjegnemo rekurziju
    tar_cmd = [
        "tar",
        "-czf", archive_file,
        "--exclude=venv",
        "--exclude=.git",
        "--exclude=__pycache__",
        "--exclude=backups", 
        "."  # Pakira cijeli trenutni folder
    ]
    
    result = subprocess.run(tar_cmd, stderr=subprocess.PIPE, text=True)
    if result.returncode == 0:
        print(f"[+] Backup uspješan: {archive_file}")
        # Brišemo privremeni SQL file jer je sada sigurno zapakiran unutar tar.gz arhive
        if os.path.exists(sql_file):
            os.remove(sql_file)
    else:
        print(f"[!] Greška kod pakiranja: {result.stderr}")

if __name__ == "__main__":
    run_backup()