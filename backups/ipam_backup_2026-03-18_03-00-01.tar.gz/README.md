# hanz-ipam
.
├── app
│   ├── api
│   │   ├── auth.py
│   │   ├── dependencies.py
│   │   ├── devices.py
│   │   ├── __init__.py
│   │   └── subnets.py
│   ├── core
│   │   ├── config.py
│   │   ├── db.py
│   │   ├── __init__.py
│   │   ├── models.py
│   │   └── security.py
│   ├── __init__.py
│   ├── main.py
│   ├── services
│   │   ├── device_service.py
│   │   ├── flash.py
│   │   ├── __init__.py
│   │   ├── subnet_service.py
│   │   └── validate.py
│   ├── static
│   │   └── style.css
│   └── templates
│       ├── base.html
│       ├── devices_add.html
│       ├── devices_edit.html
│       ├── devices_list.html
│       ├── devices_view.html
│       ├── home.html
│       ├── login.html
│       ├── subnets_list.html
│       └── subnets_view.html
├── cookies.txt
├── README.md
├── requirements.txt
├── scripts
│   ├── create_admin.py
│   └── reset_admin_pass.py
└── test_login.sh

7 directories, 33 files
