# v1.1.1
# WebSocket ruter za Turbo Scan - Optimiziran za stabilnost baze.
# Smanjen broj istovremenih pingova kako bi se izbjegao Database Lock.

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
import asyncio
import json
from app.core.db import SessionLocal
from app.services import discovery_service
from app.core.models import Subnet
import ipaddress

router = APIRouter()

@router.websocket("/ws/discovery/{subnet_id}")
async def websocket_discovery(websocket: WebSocket, subnet_id: int):
    await websocket.accept()
    
    db = SessionLocal()
    try:
        subnet = db.query(Subnet).filter(Subnet.id == subnet_id).first()
        if not subnet:
            await websocket.send_text(json.dumps({"type": "error", "message": "Subnet nije pronađen."}))
            return

        network = ipaddress.ip_network(subnet.cidr)
        hosts = [str(ip) for ip in network.hosts()]
        
        await websocket.send_text(json.dumps({"type": "start", "total": len(hosts)}))

        # KOMENTAR: Smanjen semafor na 20 radi stabilnosti SQLite baze
        semaphore = asyncio.Semaphore(20)
        tasks = [discovery_service.async_ping(ip, semaphore) for ip in hosts]

        # Obrađujemo rezultate čim stignu
        for task in asyncio.as_completed(tasks):
            try:
                ip, is_online = await task
                
                # KOMENTAR: Obrada rezultata i upis u bazu
                discovery_service.process_scan_result(db, ip, is_online, subnet_id)
                db.commit() # Ovdje sustav može zapeti ako je prebrzo

                # Slanje rezultata na frontend
                await websocket.send_text(json.dumps({
                    "type": "result",
                    "ip": ip,
                    "is_online": is_online
                }))
                
                # KOMENTAR: Kratka pauza (ms) da oslobodimo event loop
                await asyncio.sleep(0.01)

            except Exception as e:
                print(f"[!] Greška pri obradi IP-a {ip}: {e}")
                continue

        await websocket.send_text(json.dumps({"type": "finish"}))

    except WebSocketDisconnect:
        print(f"[*] Korisnik napustio scan subneta {subnet_id}")
    except Exception as e:
        print(f"[!] Kritična WS greška: {e}")
        await websocket.send_text(json.dumps({"type": "error", "message": str(e)}))
    finally:
        db.close()